<?php

	require 'banco.php';

	$id = null;
	if ( !empty($_GET['id']))
            {
		$id = $_REQUEST['id'];
            }

	if ( null==$id )
            {
		header("Location: index.php");
            }

	if ( !empty($_POST))
            {

		$tituloErro = null;
		$descricaoErro = null;
		$datapublicacaoErro = null;
              

		$titulo = $_POST['titulo'];
		$descricao = $_POST['descricao'];
		$datapublicacao = $_POST['datapublicacao'];
              
		//Validação
		$validacao = true;
		if (empty($titulo))
                {
                    $tituloErro = 'Por favor digite o titulo!';
                    $validacao = false;
                }

		

		if (empty($descricao))
                {
                    $descricao = 'Por favor digite o endereço!';
                    $validacao = false;
		}

                if (empty($datapublicacao))
                {
                    $datapublicacao = 'Por favor digite o datapublicacao!';
                    $validacao = false;
		}

                if (empty($descricao))
                {
                    $descricao = 'Por favor preenche o campo!';
                    $validacao = false;
		}

		// update data
		if ($validacao)
                {
                    $pdo = Banco::conectar();
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $sql = "UPDATE avisos  set titulo = ?, descricao = ?, datapublicacao = ? WHERE id = ?";
                    $q = $pdo->prepare($sql);
                    $q->execute(array($titulo,$descricao,$datapublicacao,$id));
                    Banco::desconectar();
                    header("Location: index.php");
		}
	}
        else
            {
                $pdo = Banco::conectar();
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT * FROM avisos where id = ?";
		$q = $pdo->prepare($sql);
		$q->execute(array($id));
		$data = $q->fetch(PDO::FETCH_ASSOC);
		$titulo = $data['titulo'];
                $descricao = $data['descricao'];
                $datapublicacao = $data['datapublicacao'];
		
		Banco::desconectar();
	}
?>

    <!DOCTYPE html>
    <html lang="pt-br">

    <head>
        <meta charset="utf-8">
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
				<title>Atualizar AVisos</title>
    </head>

    <body>
        <div class="container">

            <div class="span10 offset1">
							<div class="card">
								<div class="card-header">
                    <h3 class="well"> Atualizar Avisos</h3>
                </div>
								<div class="card-body">
                <form class="form-horizontal" action="update.php?id=<?php echo $id?>" method="post">

                    <div class="control-group <?php echo !empty($tituloErro)?'error':'';?>">
                        <label class="control-label">Titulo</label>
                        <div class="controls">
                            <input name="titulo" class="form-control" size="50" type="text" placeholder="titulo" value="<?php echo !empty($titulo)?$titulo:'';?>">
                            <?php if (!empty($tituloErro)): ?>
                                <span class="help-inline"><?php echo $tituloErro;?></span>
                                <?php endif; ?>
                        </div>
                    </div>

                    <div class="control-group <?php echo !empty($descricaoErro)?'error':'';?>">
                        <label class="control-label">Descrição</label>
                        <div class="controls">
                            <input name="descricao" class="form-control" size="80" type="text" placeholder="Descrição" value="<?php echo !empty($descricao)?$descricao:'';?>">
                            <?php if (!empty($descricaoErro)): ?>
                                <span class="help-inline"><?php echo $descricaoErro;?></span>
                                <?php endif; ?>
                        </div>
                    </div>

                    <div class="control-group <?php echo !empty($datapublicacaoErro)?'error':'';?>">
                        <label class="control-label">Data Publicação</label>
                        <div class="controls">
                            <input name="datapublicacao" class="form-control" size="30" type="date" placeholder="datapublicacao" value="<?php echo !empty($datapublicacao)?$datapublicacao:'';?>">
                            <?php if (!empty($datapublicacaoErro)): ?>
                                <span class="help-inline"><?php echo $datapublicacaoErro;?></span>
                                <?php endif; ?>
                        </div>
                    </div>

                  

                 

                    <br/>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-warning">Atualizar</button>
                        <a href="index.php" type="btn" class="btn btn-default">Voltar</a>
                    </div>
                </form>
							</div>
						</div>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <!-- Latest compiled and minified JavaScript -->
        <script src="assets/js/bootstrap.min.js"></script>
    </body>

    </html>
